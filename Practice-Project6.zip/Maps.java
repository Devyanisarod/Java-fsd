package Phase1;
import java.util.*;
import java.util.Map.Entry;
public class Maps {

	public static void main(String[] args) {
		//HashMap
		HashMap<Integer,String>hm =new HashMap<Integer,String>();
		hm.put(1, "Red");
		hm.put(2, "Orange");
		hm.put(3, "White");
		hm.put(4, "Black");
		System.out.println("The Element in Hashmap is:");
		for(Map.Entry m:hm.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());   
		}
     
		//TreeMap
	      TreeMap<Integer,String> tm=new TreeMap<Integer,String>();    
	      tm.put(7,"One");    
	      tm.put(8,"Two");    
	      tm.put(9,"Three");       
	      
	      System.out.println("\nThe elements of TreeMap are ");  
	      for(Map.Entry l:tm.entrySet()){    
	       System.out.println(l.getKey()+" "+l.getValue());    
	      }   
	      
	      //HashTable
      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
	      
	      ht.put(4,"Ales");  
	      ht.put(5,"Rosy");  
	      ht.put(6,"Jack");  
	      ht.put(7,"John");  

	      System.out.println("\nThe elements of HashTable are ");  
	      for(Map.Entry n:ht.entrySet()){    
	       System.out.println(n.getKey()+" "+n.getValue());    
	      }

	      

		
		

	}

}
