package Phase3;
import java.util.Queue;
import java.util.LinkedList;
public class QueueEx1 {

	public static void main(String[] args) {
		Queue <String> locations=new LinkedList<>();
		locations.add("pune");
		locations.add("Mumbai");
		locations.add("Delhi");
		locations.add("Hyderabad");
		locations.add("Banglore");
		locations.add("Kolkata");
		System.out.println("Queue is"+locations);
		System.out.println("Head of queue:"+locations.peek());
		locations.remove();
		System.out.println("After removing the head of the queue:"+locations);
		System.out.println("size of queue:"+locations.size());

	}

}
