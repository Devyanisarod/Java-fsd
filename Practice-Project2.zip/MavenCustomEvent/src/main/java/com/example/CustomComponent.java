package com.example;
class CustomComponent {
    private CustomListener listener;

    public void addCustomListener(CustomListener listener) {
        this.listener = listener;
    }

    public void performCustomAction() {
        // Simulate some action
        System.out.println("Custom action performed");

        // Fire custom event
        CustomEvent event = new CustomEvent(this, CustomEvent.ACTION_PERFORMED, "CustomAction");
        if (listener != null) {
            listener.customActionPerformed(event);
        }
    }
}
