package com.example;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class EventHandlingDemo {
    public static void main(String[] args) {
        // Default event handling with JButton
        JButton button = new JButton("Click me (Default)");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Button clicked (Default)");
            }
        });

        // Custom event handling with CustomComponent
        CustomComponent customComponent = new CustomComponent();
        customComponent.addCustomListener(new CustomListener() {
            @Override
            public void customActionPerformed(CustomEvent event) {
                System.out.println("Custom event handled: " + event.getActionCommand());
            }
        });
        button.doClick(); // Default event
        customComponent.performCustomAction(); // Custom event
    }
}