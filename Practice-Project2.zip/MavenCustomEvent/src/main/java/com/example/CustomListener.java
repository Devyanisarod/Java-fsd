package com.example;

interface CustomListener {
    void customActionPerformed(CustomEvent event);
}
