package com.example;

import java.awt.event.ActionEvent;

class CustomEvent extends ActionEvent {
    public CustomEvent(Object source, int id, String command) {
        super(source, id, command);
    }
}