package Phase1;
 class AccessSpecifier
{
	 private void privatemethod()
	 {
	 	System.out.println("This is a private Specifier");
	 }
	 
public void publicmethod()
{
	System.out.println("This is a public Specifier");
}

protected void protectedmethod()
{
	System.out.println("This is a protected  Specifier");
}
void defaultmethod()
{
	System.out.println("This is default method");
}
}

public class AccessSpecifier1 {

	public static void main(String[] args) {
		System.out.println("public Specifier");
		AccessSpecifier a= new AccessSpecifier();
		a.publicmethod();
		a.protectedmethod();
		a.defaultmethod();
		
		
		
		
		
       
	}

}
