package Phase1;

public class StringOperations {

	public static void main(String[] args) {
		String s1="string functions program";
		String s2="String functions";
		System.out.println("String Operations:");
		System.out.println(s1.charAt(2));
        System.out.println(s1.codePointAt(3));
        System.out.println(s1.codePointBefore(1));
        System.out.println(s1.codePointCount(0, 5));
        System.out.println("String comparison functions:");
        System.out.println(s1.compareTo(s2));
        System.out.println(s1.compareToIgnoreCase(s2));
        System.out.println(s1.concat(s2));
        System.out.println(s1.contains(s2));
        System.out.println(s1.endsWith("gram"));
        System.out.println(s1.equals(s2));
        System.out.println(s1.equalsIgnoreCase(s2));
        System.out.println(s1.hashCode());
        System.out.println(s1.indexOf("program"));
        System.out.println(s1.isEmpty());
        System.out.println(s1.length());
        System.out.println(s1.toLowerCase());
        System.out.println(s1.toUpperCase());
        
     // conversion from String object to StringBuffer 
        StringBuffer sbr = new StringBuffer(s1); 
        sbr.reverse(); 
        System.out.println("String to StringBuffer");
        System.out.println(sbr); 

        
     // conversion from String object to StringBuilder 
        StringBuilder sbl = new StringBuilder(s1); 
        sbl.append("world"); 
        System.out.println("String to StringBuilder");
        System.out.println(sbl);              		
	}

	}

	

