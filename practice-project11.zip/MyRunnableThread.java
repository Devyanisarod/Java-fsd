package Phase2;

public class MyRunnableThread implements Runnable {
	public static int mycount=0;
	public void run() {

		while(MyRunnableThread.mycount<=7)
		{
			try {
				System.out.println("expl Thread:"+(++MyRunnableThread.mycount));
				Thread.sleep(100);
			}
			catch(InterruptedException e)
			{
				System.out.println("Exception in Thread:"+e.getMessage());
			}
		}
	}
	public static void main(String[] args) {
		System.out.println("starting Main Thread");
		MyRunnableThread m= new MyRunnableThread ();
		Thread t=new Thread(m);
		t.start();
		while(MyRunnableThread.mycount<=7)
		{
			try {
				System.out.println("main Thread:"+(++MyRunnableThread.mycount));
				Thread.sleep(100);
			}
			catch(InterruptedException e)
			{
				System.out.println("Exception in Thread:"+e.getMessage());
			}
		}
		System.out.println("End Main Thread");
	}
}
