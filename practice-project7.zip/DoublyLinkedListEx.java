package Phase3;
public class DoublyLinkedListEx {
	class Node {
		int data;
		Node next;
		Node prev;
		Node(int data) {
			this.data = data;
			this.next = null;
			this.prev = null;
		}
	}
	Node head;
	void insert(int data) {
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
		} else {
			newNode.next = head;
			head.prev = newNode;
			head = newNode;
		}
	}
	void traverseForward() {
		Node current = head;
		while (current != null) {
			System.out.print(current.data + " ");
			current = current.next;
		}
		System.out.println();
	}
	void traverseBackward() {
		Node current = head;
		while (current.next != null) {
			current = current.next;
		}
		while (current != null) {
			System.out.print(current.data + " ");
			current = current.prev;
		}
		System.out.println();
	}
	public static void main(String[] args) {
		DoublyLinkedListEx list = new DoublyLinkedListEx();
		list.insert(1);
		list.insert(7);
		list.insert(6);
		list.insert(8);
		list.insert(4);
		System.out.println("Forward traversal:");
		list.traverseForward();
		System.out.println("Backward traversal:");
		list.traverseBackward();
	}
}


