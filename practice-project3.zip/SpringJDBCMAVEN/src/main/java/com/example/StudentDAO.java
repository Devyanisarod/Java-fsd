package com.example;
import org.springframework.jdbc.core.JdbcTemplate;
public class StudentDAO {
	private JdbcTemplate temp;

	public void setTemp(JdbcTemplate temp) {
		this.temp = temp;
	}
	public int insert(Student sobj) {
		String sql="insert into student values("+sobj.getId()+",'"+sobj.getName()+"','"+sobj.getEmail()+"')";
		//insert update delete 
		return temp.update(sql);
		


}
}