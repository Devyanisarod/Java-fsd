package Phase3;
public class ArrayRotation {
	public static void main(String[] args) {
		int [] arr = new int [] {12,13,14,15,16,17,18};     
		int n = 5,i;    
		System.out.println("array is : ");    
		for ( i = 0; i < arr.length; i++) 
		{     
			System.out.print(arr[i] + " "); 
		}
		for( i = 0; i < n; i++)
		{    
			int j, last;    
			last = arr[arr.length-1];    
			for(j = arr.length-1; j > 0; j--)
			{    
				arr[j] = arr[j-1];    
			}    
			arr[0] = last;    
		}    
		System.out.println();   
		System.out.println("Array after right rotation: ");    
		for(i = 0; i< arr.length; i++){    
			System.out.print(arr[i] + " ");    
		}    
	}    
}      



