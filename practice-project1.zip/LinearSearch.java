package phaseData;
import java.util.Scanner;
public class LinearSearch {
	public static void main(String[] args) {

		int a[]= {3,5,2,9,6,8};
		int key;
		int temp=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a Element to be searched:");
		key=sc.nextInt();
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==key)
			{
				System.out.println(+key+ " element is found at "+i);
				temp=temp+1;
			}
		}
		if(temp==0)
		{
			System.out.println("element not found");
		}
	}
}
