package Phase2;

public class TryCatchDemo {
	public static void main(String[] args)
	{
		try
		{
			int data=70/0;
		}
		catch(ArithmeticException e)
		{
			e.printStackTrace();
		}
		finally
		{
			System.out.println("program is run");
		}
	}

}
