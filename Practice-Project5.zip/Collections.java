package Phase1;
import java.util.*;
public class Collections {
	//ArrayList
	public static void main(String[] args) {
		System.out.println("ArrayList");
		ArrayList<String> name=new ArrayList<String>();  
		name.add("Alex");
		name.add("John");
		name.add("Alia");
		System.out.println(name);

		//LinkedList
		System.out.println("LinkedList");
		LinkedList<String> al=new LinkedList<String>();
		al.add("Mango");
		al.add("Kiwi");
		al.add("Grapes");
		al.add("Watermelon");
		System.out.println(al);

		//HashSet
		System.out.println("HashSet");
		HashSet<String>set=new HashSet<String>();
		set.add("One");
		set.add("Two");
		set.add("Three");
		set.add("Four");
		System.out.println(set);

		//LinkedHashSet
		System.out.println("LinkedHashSet");
		LinkedHashSet<Integer> s=new LinkedHashSet<Integer>();  
		s.add(20);  
		s.add(30);  
		s.add(40);
		s.add(50);	       
		System.out.println(s);
	}

}
