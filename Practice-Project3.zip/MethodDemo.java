package Phase1;

public class MethodDemo {
	int data=50;
	//method
	public int addnumber(int a,int b)
	{
		int x=a+b;
		return x;
	}
	// call by value
	void change(int data)
	{
		data=data+100;
	}
	//Method Overloading
	void add(int a,int b)
	{
		System.out.println("addition is:"+(a+b));
	}
	void add(int x,int y,int z)
	{
		System.out.println("Addition is:"+(x+y+z));
	}

	
	public static void main(String[] args) {
		MethodDemo m=new MethodDemo();
		System.out.println("Method:");
		int add=m.addnumber(40, 50);
		System.out.println("The addition of two nuumbers is:"+add);
		System.out.println("call by value:");
		System.out.println("before change"+m.data);
		m.change(200);
		System.out.println("after change"+m.data);
		System.out.println("Method Overloading:");
		m.add(100, 200);
		m.add(300, 400, 500);
	}

}
