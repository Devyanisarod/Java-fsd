package com.PhaseEndProj;
import java.util.ArrayList;
public class MyCamera {
	public static ArrayList<Camera> myCamera = new ArrayList<>();
}

