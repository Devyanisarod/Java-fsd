package Phase2;

import java.io.IOException;

class M
{
	void method()throws IOException
	{
		throw new IOException("device error");
	}
}
public class ThrowsDemo {

	public static void main(String[] args) {
		try
		{
			M m=new M();
			m.method();
		}
		catch(Exception e)
		{
			System.out.println("Exception Handled");
		}
		System.out.println("program continue");
	}

}
