package Phase2;

public class ThrowDemo {
	public static void validation(int age)
	{
		if(age<18)
		{
			throw new ArithmeticException("person is not eligible to vote");
		}
		else
		{
			System.out.println("person is eligible to vote");
		}
	}

	public static void main(String[] args) {
		validation(10);
		System.out.println("rest of code");
		
	}

}
