package Phase1;

public class InnerClassEx {
	public class InsideClass
	{
		public void Display()
		{
			int a=10,b=20;
			System.out.println("Addition:"+(a+b));
			
		}
	}
	public static void main(String[] args) {
		InnerClassEx e1= new InnerClassEx();
		InnerClassEx.InsideClass e3=e1.new InsideClass();
		e3.Display();
	}
}
