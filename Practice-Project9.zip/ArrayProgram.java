package Phase1;

public class ArrayProgram {

	public static void main(String[] args) {
		System.out.println("Single Dimension Array:");
		int a[]=new int[5];
		a[0]=20;
		a[1]=30;
		a[2]=50;
		a[3]=40;
		System.out.println("Elements in array are:"+a[0]+" "+a[1]+" "+a[2]+" "+a[3]);


		//Multidimensional Array
		System.out.println("Multidimensional Array");
		int b[][]= {{5,7,8,9},{11,53,24}};
		System.out.println("\nLength of row 1: " + b[0].length);
	}
}