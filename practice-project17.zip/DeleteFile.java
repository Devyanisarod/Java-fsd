package Phase2;
import java.io.File;
import java.io.IOException;
public class DeleteFile {
	public static void main(String[] args) {
		File m1=new File("Project.txt");
		if(m1.delete())
		{
			System.out.println("Deleted File:"+m1.getName());
		}
		else 
		{
			System.out.println("some problem occurred while deleting a file");
		}

	}

}
