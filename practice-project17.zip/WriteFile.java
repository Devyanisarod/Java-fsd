package Phase2;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
public class WriteFile {
	public static void main(String[] args) {
		try {
			FileWriter f1=new FileWriter("Project.txt");
			f1.write("This is a java program");
			f1.close();
			System.out.println("Successfully Write a file");
		}catch(IOException e)
		{
			e.printStackTrace();
		}
	}	
}
