package Phase1;
public class constructorType {
	double length,breadth,height,volume;
	constructorType()
	{
		length=10;
		breadth=20;
		height=30;
		volume =length*breadth*height;
		System.out.println("Volume is:" +volume);
	}
		
		constructorType(double l, double b,double h)
		{
			length=l;
			breadth=b;
			height=h;
			volume =length*breadth*height;
			System.out.println("Volume is:" +volume);
		


}
	public static void main(String[] args) {
		constructorType a=new constructorType();
		constructorType b=new constructorType(50,60,70);
		
		
	}
	}
