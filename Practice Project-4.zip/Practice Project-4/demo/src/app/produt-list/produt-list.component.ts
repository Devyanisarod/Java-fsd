import { Component } from '@angular/core';

@Component({
  selector: 'app-produt-list',
  templateUrl: './produt-list.component.html',
  styleUrl: './produt-list.component.css'
})
export class ProdutListComponent {

}
