package Phase2;

class MyException extends Exception
{
	String str1;
	MyException(String str2)
	{
		str1=str2;
	}
	public String toString()
	{
		return("Exception occurred:" +str1);
	}
}
 class Exceptionpg {
	public static void main(String[] args) {
		try
		{
			System.out.println("Start try block ");
			throw new MyException("This is Error Message");
		}
		catch(MyException e)
		{
			System.out.println("catch block");
			System.out.println(e);
		}
	}
}



