package Phase2;
class person
{
	private String name;
	private int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
}
public class Encapsulation1 {
	public static void main(String[] args) {
		person p=new person();
		p.setName("Alex");
		p.setAge(34);
		System.out.println("person name:"+p.getName());
		System.out.println("person age:"+p.getAge());
	}

}
