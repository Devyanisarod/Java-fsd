package Phase2;

public class Polymorphism1 {
	public int sum(int a,int b)
	{
		return (a+b);
	}
	public int sum(int a,int b,int c)
	{
		return (a+b+c);
	}
	public double sum(double a,double b)
	{
		return(a+b);
	}
	public static void main(String[] args) {
		Polymorphism1 p=new Polymorphism1();
		System.out.println(p.sum(30,40));
		System.out.println(p.sum(30, 40, 50));
		System.out.println(p.sum(50.3, 60.6));
	}
}
