package Phase2;

public class Employee {
	int id,salary;
	String name;
	void display()
	{
		System.out.println("Employee ID is: "+id);
		System.out.println("Employee name is: "+name);
		System.out.println("Employee Salary is: "+salary);
	}
	public static void main(String[] args) {
		Employee e=new Employee();
		e.id=101;
		e.name="John";
		e.salary=10000;
		e.display();
	}

}
