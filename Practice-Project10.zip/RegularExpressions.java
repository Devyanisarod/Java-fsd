package Phase1;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressions {
	public static void main(String[] args) {
		List < String > names = new ArrayList < String > ();
		names.add("Java");
		names.add("Python-----");
		names.add("CPP");

		String regex = "^[a-zA-Z0-9]+$";

		Pattern pattern = Pattern.compile(regex);

		for (String name: names) {
			Matcher matcher = pattern.matcher(name);
			System.out.println(matcher.matches());
		}
		
		//Another way
		String pattern1 = "[a-z]+";
		String check = "Regular Expressions";
		Pattern p = Pattern.compile(pattern1);
		Matcher c = p.matcher(check);
		
		while (c.find())
	      	System.out.println( check.substring( c.start(), c.end() ) );
		}

	}


