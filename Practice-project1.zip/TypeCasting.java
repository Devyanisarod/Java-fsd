package Phase1;

public class TypeCasting {

	public static void main(String[] args) {

		System.out.println("Implicit Type Casting");
		int a=10;
		double b=a;
		System.out.println(b);
		float c=a;
		System.out.println(c);
		long d=a;
		System.out.println(d);

		System.out.println("Explicit Type Casting");
		float f=100.5f;
		int i=(int)f;
		System.out.println(i);

	}

}
