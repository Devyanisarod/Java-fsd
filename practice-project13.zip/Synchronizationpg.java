package Phase2;
class First
{
	public void display(String msg)
	{
		System.out.print("["+msg);

		try
		{
			Thread.sleep(1000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		System.out.println("]");
	}
}
class second extends Thread
{
	String msg;
	First fobj;
	second(First fp,String str)
	{
		fobj=fp;
		msg=str;
		start();
	}
	public void run()
	{
		synchronized (fobj)
		{
			fobj.display(msg);
		}
	}
}
public class Synchronizationpg {
	public static void main(String[] args)
	{
		First f1=new First();
		second s1=new second(f1,"Welcome");
		second s2=new second(f1,"new");
		second s3=new second(f1,"programmer");
	}
}
